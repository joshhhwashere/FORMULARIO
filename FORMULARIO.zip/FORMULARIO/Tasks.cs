﻿using System.ComponentModel;

namespace ToDoListApp
{
    public class Tasks                                          
    {
        public string TaskName { get; set; }

        public string Status { get; set; }
    }
}
